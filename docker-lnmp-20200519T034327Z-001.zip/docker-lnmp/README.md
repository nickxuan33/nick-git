# docker-lnmp
docker的LNMP+REDIS環境

使用說明:
    這個是針對沒有載任何東西，只有DOCKER跟GIT的環境
    如果已有NGINX，PHP，MYSQL，REDIS請先關閉或是另外
    開啟PORT。
   
    首先下載DOCKER和GIT
    $ sudo yum update -y && yum clean all
    $ sudo yum install -y epel-release
    $ sudo yum install -y docker git

    安裝docker-compose
    $ curl -L https://github.com/docker/compose/releases/download/1.21.2/docker-compose-`uname -s`-`uname -m` -o /usr/local/bin/docker-compose
    $ chmod +x /usr/local/bin/docker-compose

    $ sudo groupadd docker
    $ sudo gpasswd -a ${USER} docker
    $ sudo systemctl restart docker

    $ sudo iptables -F
    $ sudo systemctl stop firewalld.service
    $ sudo systemctl disable firewalld.service

    關閉selinux，找到 SELINUX=enforcing 將其改成 SELINUX=disabled
    $ sudo vi /etc/selinux/config

    $ sudo service docker start
    $ sudo systemctl enable docker
    $ sudo reboot

*****************************************************************

    接著在DOCKER這層資料夾下
    依照compose設定將所有環境建置起來
    $ docker-compose up -d

    完成後執行
    $ docker-compose run php composer install
    確保透過composer管理函式庫都有安裝完成。包含phpunit

    修改compose設定或service參數後如需要重建生效
    $ docker-compose up -d --build

    清空所有環境
    $ docker-compose down --rmi local

    service參數檔可以在docker資料夾裡找到，修改後記得執行以下命令生效
    $ docker-compose up -d --build

    如需要查看service的log可以使用
    $ docker logs CONTAINER

*****************************************************************

    查詢容器IP位置:
    查詢容器IP : 
    $ docker ps
    $ docker inspect <容器ID> | grep IPAddress

    外部連接指令 : 
    REDIS -> $ redis-cli -h <ipaddress> -p 6379
    MYSQL -> $ mysql -u root -h  <ipaddress> -p 3306

                               ↓容器ID
    DOCKER連接指令 : 
    REDIS -> $ docker exec -it 43f7a65ec7f8 redis-cli
    MYSQL -> $ docker exec -it 43f7a65ec7f8 mysql -u root -p

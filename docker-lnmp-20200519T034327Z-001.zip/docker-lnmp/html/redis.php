<?php
$redis = new Redis();
   $redis->connect('172.20.0.2', 6379);
   echo "Connection to server sucessfully";
   echo "Server is running: " . $redis->ping();

?>

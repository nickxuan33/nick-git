<?php
namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Cache\Adapter\RedisAdapter;

class BankController extends Controller
{
    /**
     * 新增出入款資料且顯示出此次的明細
     * @Route("/api/bank/{id}/new",
     *  name="api_bank_new",
     *  requirements={"id"="\d+"})
     * @Method({"POST"})
     * @param Request $request
     * @param integer $id
     * @return JsonResponse
     */
    public function newAction(Request $request, $id)
    {
        $post = $request->request;
        $money = $post->get('money');
        $type = $post->get('type');

        if (!preg_match("/^\d+$/", $money)) {
            return new JsonResponse("money is not integer!");
        }

        if (!preg_match("/^[A-Za-z]+$/", $type)) {
            return new JsonResponse("type is not string!");
        }

        $redis = RedisAdapter::createConnection (
            'redis://172.18.0.2:6379',
            array (
                'persistent' => 0,
                'persistent_id' => null,
                'timeout' => 30,
                'read_timeout' => 0,
                'retry_interval' => 0,
            )
        );

        $time = new \DateTime("Asia/Taipei");
        $name = $redis->HGET('user_id', $id);

        if ($type == "withdraw") {
            $balance = $redis->HINCRBY('user', $name, $money * (-1));

            if ($balance < 0) {
                $balance = $redis->HINCRBY('user', $name, $money);
                return new JsonResponse("Your balance is not enough!");
            }

        } elseif ($type == "deposit") {
            $balance = $redis->HINCRBY('user', $name, $money);
        } else {
            return new JsonResponse("type error!");
        }

        $test = $id . "," . $name . "," . $money . "," . $type;
        $test .= "," . $time->format("Y/m/d H:i:s") . "," . $balance;
        $redis->LPUSH('bank', $test);

        $data = array (
            "id" => $id,
            "name" => $name,
            "money" => $money,
            "type" => $type,
            "time" => $time->format("Y/m/d H:i:s"),
            "balance" => $balance
        );

        return new JsonResponse($data);
    }

    /**
     * 顯示所有出入款明細
     * @Route("/api/bank/show",
     *  name="api_bank_show")
     * @Method({"GET"})
     * @param Request $request
     * @return JsonResponse
     */
    public function showRecordsAction(Request $request)
    {
        $get = $request->query;
        $page = $get->get('page', 0);
        $count = $get->get('count', 0);

        $redis = RedisAdapter::createConnection (
            'redis://172.18.0.2:6379',
            array (
                'persistent' => 0,
                'persistent_id' => null,
                'timeout' => 30,
                'read_timeout' => 0,
                'retry_interval' => 0,
            )
        );

        if (!preg_match("/^\d+$/", $page) || $page < 0) {
            return new JsonResponse("page is not integer!");
        }

        if (!preg_match("/^\d+$/", $count) || $count < 0) {
            return new JsonResponse("count is not integer!");
        }

        $totalRecords = $redis->LRANGE('bank', $page, $count);

        return new JsonResponse($totalRecords);
    }
}

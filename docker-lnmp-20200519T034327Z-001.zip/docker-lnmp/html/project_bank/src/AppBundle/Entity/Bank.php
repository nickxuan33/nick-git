<?php
namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="AppBundle\Repository\BankRepository")
 * @ORM\Table(name="bank")
 */
class Bank
{
    /**
     * 交易紀錄序號
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * 會員名稱
     * @ORM\ManyToOne(targetEntity="AppBundle\Entity\User")
     * @ORM\JoinColumn(name="name", referencedColumnName="id")
     */
    protected $name;

    /**
     * 交易金額
     * @ORM\Column(type="integer")
     */
    protected $money;

    /**
     * 交易形式(入款或出款)
     * @ORM\Column(type="string")
     */
    protected $type;

    /**
     * 交易時間
     * @ORM\Column(type="datetime")
     */
    protected $time;

    /**
     * 餘額
     * @ORM\Column(type="integer")
     */
    protected $balance;

    /**
     * 顯示此次交易紀錄
     */
    public function toArray()
    {
        return [
            'id' => $this->id,
            'money' => $this->money,
            'type' => $this->type,
            'time' => $this->time->format("Y/m/d H:i:s"),
            'balance' => $this->balance
        ];
    }

    /**
     * 取得交易紀錄id
     *
     * @ORM\return $this->id
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * 取得會員名稱
     *
     * @ORM\return $this->name
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * 設定會員名稱
     *
     * @ORM\param string $name
     */
    public function setName($name)
    {
        $this->name = $name;
        return $this;
    }

    /**
     * 取得交易金額
     *
     * @ORM\return $this->money
     */
    public function getMoney()
    {
        return $this->money;
    }

    /**
     * 設定交易金額
     *
     * @ORM\param integer $money
     */
    public function setMoney($money)
    {
        $this->money = $money;
    }

     /**
     * 取得交易形式
     *
     * @ORM\return $this->type
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * 設定交易形式
     *
     * @ORM\param string $type
     */
    public function setType($type)
    {
        $this->type = $type;
    }

    /**
     * 取得交易時間
     *
     * @ORM\return $this->time
     */
    public function getTime()
    {
        return $this->time;
    }

    /**
     * 設定交易時間
     *
     * @ORM\param datatime $time
     */
    public function setTime(\Datetime $time)
    {
        $this->time = $time;
    }

    /**
     * 取得餘額
     *
     * @ORM\return $this->balance
     */
    public function getBalance()
    {
        return $this->balance;
    }

    /**
     * 設定餘額
     *
     * @ORM\param integer $balance
     */
    public function setBalance($balance)
    {
        $this->balance = $balance;
    }
}

<?php
namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="user")
 */
class User
{
    /**
     * 會員序號
     * @ORM\Id
     * @ORM\Column(type="integer")
     */
    protected $id;

    /**
     * 會員名稱
     * @ORM\Column(type="string")
     */
    protected $name;

    /**
     * 會員錢包餘額
     * @ORM\Column(type="integer")
     */
    protected $balance;

    /**
     * 取得會員id
     *
     * @ORM\return $this->id
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * 設定會員id
     *
     * @ORM\param integer $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * 取得會員名稱
     *
     * @ORM\return $this->name
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * 設定會員名稱
     *
     * @ORM\param integer $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * 取得餘額
     *
     * @ORM\return $this->balance
     */
    public function getBalance()
    {
        return $this->balance;
    }

    /**
     * 設定餘額
     *
     * @ORM\param integer $balance
     */
    public function setBalance($balance)
    {
        $this->balance = $balance;
    }
}

<?php
namespace AppBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Input\InputOption;
use AppBundle\Entity\Bank;

class CreateDataCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this->setName('create:data')
            ->setDescription('Create new details.')
            ->setHelp("This command allows you to create bank details...")
            ->addOption(
                'count',
                null,
                InputOption::VALUE_REQUIRED,
                '輸入筆數',
                1
            )
            ->addOption(
                'amount',
                null,
                InputOption::VALUE_REQUIRED,
                '輸入金額',
                1
            );
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $timeStart = microtime(TRUE);
        $count = $input->getOption('count');
        $money = $input->getOption('amount');
        $connection = $this->getContainer()->get('doctrine')->getConnection();
        $user = $connection->fetchColumn('SELECT id FROM user where name = ?', array('james'), 0);

        for ($i = 1; $i <= $count; $i++) {
            $userBalance = $connection->fetchColumn('SELECT balance FROM user where name = ?', array('james'), 0);
            $total = $userBalance + $money;
            $connection->executeUpdate('UPDATE user SET balance = ? WHERE id = ?', array($total, 1));
            $time = new \DateTime("Asia/Taipei");
            $connection->insert('bank',
                array(
                    'money' => $money,
                    'type' => 'deposit',
                    'time' => $time->format('Y/m/d H:i:s'),
                    'balance' => $total,
                    'name' => $user
            ));
        }

        $memory = memory_get_peak_usage(TRUE)/1024/1024;
        $excuteTime = round((microtime(TRUE) - $timeStart), 4);
        $output->writeln("\033[01;31mTime Used : \033[0m" . $excuteTime . "s\n");
        $output->writeln("\033[01;31mMemory Used : \033[0m" . $memory . "MB\n");
    }
}
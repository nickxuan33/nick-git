<?php
namespace AppBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Cache\Adapter\RedisAdapter;
use AppBundle\Entity\Bank;

class CreateBankCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this->setName('create:bank')
            ->setDescription('Create new details.')
            ->setHelp("This command allows you to create bank details...");
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $timeStart = microtime(TRUE) * 1000;
        $entityManager = $this->getContainer()->get('doctrine')->getManager();
        $redis = RedisAdapter::createConnection (
            'redis://172.18.0.2:6379',
            array (
                'persistent' => 0,
                'persistent_id' => null,
                'timeout' => 30,
                'read_timeout' => 0,
                'retry_interval' => 0,
            )
        );

        $totalCount = $redis->LLEN('bank');

        for ($i = 1; $i <= $totalCount; $i++) {
            $data = $redis->RPOP('bank');
            $stringData = explode(",", $data);
            $id = $stringData[0];
            $money = $stringData[2];
            $type = $stringData[3];
            $time = $stringData[4];
            $datatime = date_create_from_format('Y/m/d H:i:s', $time);
            $balance = $stringData[5];
            $user = $entityManager->getRepository('AppBundle:User')->find($id);
            $user->setBalance($balance);
            $bank = new Bank();
            $bank->setName($user);
            $bank->setMoney($money);
            $bank->setTime($datatime);
            $bank->setType($type);
            $bank->setBalance($balance);
            $entityManager->persist($bank);
            $entityManager->flush();
        }

        $memory = memory_get_peak_usage(TRUE)/1024/1024;
        $excuteTime = round((microtime(TRUE) * 1000 - $timeStart), 4);
        $output->writeln("Insert into database is success !");
        $output->writeln("\033[01;31mTime Used : \033[0m" . $excuteTime . "ms\n");
        $output->writeln("\033[01;31mMemory Used : \033[0m" . $memory . "MB\n");
    }
}

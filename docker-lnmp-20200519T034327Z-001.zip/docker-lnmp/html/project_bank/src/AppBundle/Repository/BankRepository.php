<?php
namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;

class BankRepository extends EntityRepository
{
    /**
     * 取得最新一筆餘額紀錄
     */
    public function getPreviousBalance($id)
    {
        $query = $this->createQueryBuilder('b')
            ->select('b.balance')
            ->where('b.name = :name')
            ->setParameter('name', $id)
            ->orderBy('b.id', 'DESC')
            ->getQuery();

        $max = $query->setMaxResults(1);

        return $max->getSingleScalarResult();
    }

    /**
     * 取得全部交易紀錄
     */
    public function getTotalRecords($page, $count)
    {
        $query = $this->createQueryBuilder('b')
            ->leftJoin("b.name", "n")
            ->addSelect("n")
            ->orderBy('b.id', 'DESC')
            ->getQuery();

        $max = $query->setFirstResult($count * ($page - 1))
            ->setMaxResults($count);

        return $max->getArrayResult();
    }
}

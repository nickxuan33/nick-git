<?php
namespace tests\AppBundle\Repository;

use AppBundle\Entity\Bank;
use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;

class BankRepositoryTest extends KernelTestCase
{
    /**
     * @var \Doctrine\ORM\EntityManager
     */
    private $entityManager;

    protected function setUp()
    {
        $kernel = self::bootKernel();

        $this->entityManager = $kernel->getContainer()
            ->get('doctrine')
            ->getManager();
    }

    /**
     * 測試取得最新一筆餘額紀錄
     */
    public function testGetPreviousBalance()
    {
        $query = $this->entityManager
            ->getRepository(Bank::class)
            ->getPreviousBalance(1);

        $this->assertEquals(1, $query);
    }

    /**
     * 測試取得全部交易紀錄
     */
    public function testGetTotalRecords()
    {
        $query = $this->entityManager
            ->getRepository(Bank::class)
            ->getTotalRecords(1, 3);

        $this->assertEquals('james', $query[0]['name']['name']);
        $this->assertEquals(8, $query[0]['id']);
    }

    /**
     * {@inheritDoc}
     */
    protected function tearDown()
    {
        parent::tearDown();

        $this->entityManager->close();
        $this->entityManager = null;
    }
}

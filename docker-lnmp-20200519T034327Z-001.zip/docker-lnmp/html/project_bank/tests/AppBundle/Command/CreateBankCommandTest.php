<?php
namespace tests\AppBundle\Command;

use AppBundle\Command\CreateBankCommand;
use Symfony\Bundle\FrameworkBundle\Console\Application;
use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;
use Symfony\Component\Console\Tester\CommandTester;
use Symfony\Component\Cache\Adapter\RedisAdapter;

class CreateBankCommandTest extends KernelTestCase
{
    /**
     * @var \Doctrine\ORM\EntityManager
     */
    private $entityManager;

    protected function setUp()
    {
        $kernel = self::bootKernel();

        $this->entityManager = $kernel->getContainer()
            ->get('doctrine')
            ->getManager();

        $redis = RedisAdapter::createConnection (
            'redis://127.0.0.1:6379/1',
            array (
                'persistent' => 0,
                'persistent_id' => null,
                'timeout' => 30,
                'read_timeout' => 0,
                'retry_interval' => 0,
            )
        );

        $createTime = new \DateTime("Asia/Taipei");
        for ($i = 1; $i <= 3; $i++) {
            $string = "1,james,1,deposit," . $createTime->format("Y/m/d H:i:s") . "," . $i;
            $redis->LPUSH('bank', $string);
        }
    }

    public function testExecute()
    {
        $kernel = static::createKernel();
        $kernel->boot();

        $application = new Application($kernel);
        $application->add(new CreateBankCommand());

        $command = $application->find('create:bank');
        $commandTester = new CommandTester($command);
        $commandTester->execute(array(
            'command'  => $command->getName()
        ));

        for ($i = 1; $i <= 3; $i++) {
            $time = new \DateTime("Asia/Taipei");
            $bank = $this->entityManager->find('AppBundle:Bank', $i);
            $user = $this->entityManager->getRepository('AppBundle:User')->find(1);
            $this->assertEquals($user, $bank->getName());
            $this->assertEquals(1, $bank->getMoney());
            $this->assertEquals('deposit', $bank->getType());
            $this->assertEquals($time->format('Y/m/d H:i:s'), $bank->getTime()->format('Y/m/d H:i:s'));
        }

        $user = $this->entityManager->getRepository('AppBundle:User')->find(1);
        $this->assertEquals(3, $user->getBalance());
        $output = $commandTester->getDisplay();
        $this->assertContains("Insert into database is success !", $output);
    }
}
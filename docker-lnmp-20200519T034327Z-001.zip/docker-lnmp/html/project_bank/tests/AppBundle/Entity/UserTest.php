<?php
namespace tests\AppBundle\Entity;

use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;
use AppBundle\Entity\User;

class UserTest extends KernelTestCase
{
    /**
     * @var \Doctrine\ORM\EntityManager
     */
    private $entityManager;

    protected function setUp()
    {
        $kernel = self::bootKernel();

        $this->entityManager = $kernel->getContainer()
            ->get('doctrine')
            ->getManager();
    }

    public function testUser()
    {
        $user = new User();
        $user->setId(12);
        $user->setName('andy');
        $user->setBalance(5);
        $this->entityManager->persist($user);
        $this->entityManager->flush();

        $this->assertEquals(12, $user->getId());
        $this->assertEquals('andy', $user->getName());
        $this->assertEquals(5, $user->getBalance());
    }
}

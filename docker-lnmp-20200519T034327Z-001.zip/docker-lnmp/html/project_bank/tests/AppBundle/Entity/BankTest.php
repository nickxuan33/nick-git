<?php
namespace tests\AppBundle\Entity;

use AppBundle\Entity\Bank;
use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;

class BankTest extends KernelTestCase
{
    /**
     * @var \Doctrine\ORM\EntityManager
     */
    private $entityManager;

    protected function setUp()
    {
        $kernel = self::bootKernel();

        $this->entityManager = $kernel->getContainer()
            ->get('doctrine')
            ->getManager();
    }

    public function testBank()
    {
        $user = $this->entityManager->getRepository('AppBundle:User')->find(1);
        $bank = new Bank();
        $bank->setName($user);
        $bank->setMoney(1);
        $bank->setType('deposit');
        $bank->setBalance(1);
        $bank->setTime(new \DateTime("Asia/Taipei"));
        $this->entityManager->persist($bank);
        $this->entityManager->flush();

        $time = new \DateTime("Asia/Taipei");
        $checkArray = $bank->toArray();
        $this->assertEquals(6, $checkArray['id']);
        $this->assertEquals(1, $checkArray['money']);
        $this->assertEquals('deposit', $checkArray['type']);
        $this->assertEquals($time->format('Y/m/d H:i:s'), $checkArray['time']);
        $this->assertEquals(1, $checkArray['balance']);
        $this->assertEquals(6, $bank->getId());
        $this->assertEquals($user, $bank->getName());
        $this->assertEquals(1, $bank->getMoney());
        $this->assertEquals('deposit', $bank->getType());
        $this->assertEquals(1, $bank->getBalance());
        $this->assertEquals($time->format('Y/m/d H:i:s'), $bank->getTime()->format('Y/m/d H:i:s'));
    }
}

<?php
namespace tests\AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class BankControllerTest extends WebTestCase
{
    /**
     * 測試新增入款資料
     */
    public function testDepositNewAction()
    {
        $client = static::createClient();
        $data = array('money' => 1, 'type' => 'deposit');
        $client->request('POST',
            '/api/bank/1/new',
            $data,
            array(),
            array(),
            ['Content-Type' => 'application/x-www-form-urlencoded']);
        $response = $client->getResponse()->getContent();
        $params = json_decode($response, true);
        $this->assertEquals(1, $params['money']);
        $this->assertEquals('deposit', $params['type']);
        $this->assertEquals(200, $client->getResponse()->getStatusCode());
        $this->assertTrue($client->getResponse()->isSuccessful());
    }

    /**
     * 測試新增出款資料
     */
    public function testWithdrawNewAction()
    {
        $client = static::createClient();
        $data = array('money' => 1, 'type' => 'withdraw');
        $client->request('POST',
            '/api/bank/1/new',
            $data,
            array(),
            array(),
            ['Content-Type' => 'application/x-www-form-urlencoded']);
        $response = $client->getResponse()->getContent();
        $params = json_decode($response, true);
        $this->assertEquals(1, $params['money']);
        $this->assertEquals('withdraw', $params['type']);
        $this->assertEquals(200, $client->getResponse()->getStatusCode());
        $this->assertTrue($client->getResponse()->isSuccessful());
    }

    /**
     * 測試新增出款資料錯誤
     */
    public function testDepositErrorAction()
    {
        $client = static::createClient();
        $data = array('money' => 100, 'type' => 'withdraw');
        $client->request('POST',
            '/api/bank/1/new',
            $data,
            array(),
            array(),
            ['Content-Type' => 'application/x-www-form-urlencoded']);
        $this->assertEquals("Your balance is not enough!", json_decode($client->getResponse()->getContent()));
    }

    /**
     * 測試 post $money 錯誤訊息
     */
    public function testErrorPostMoney()
    {
        $client = static::createClient();
        $data = array('money' => 'test', 'type' => 'deposit');
        $client->request('POST',
            '/api/bank/1/new',
            $data,
            array(),
            array(),
            ['Content-Type' => 'application/x-www-form-urlencoded']);
        $this->assertEquals(200, $client->getResponse()->getStatusCode());
        $this->assertEquals("money is not integer!", json_decode($client->getResponse()->getContent()));
    }

    /**
     * 測試 post $type 錯誤訊息
     */
    public function testErrorPostType()
    {
        $client = static::createClient();
        $data = array('money' => 1, 'type' => 123);
        $client->request('POST',
            '/api/bank/1/new',
            $data,
            array(),
            array(),
            ['Content-Type' => 'application/x-www-form-urlencoded']);
        $this->assertEquals(200, $client->getResponse()->getStatusCode());
        $this->assertEquals("type is not string!", json_decode($client->getResponse()->getContent()));
    }

    /**
     * 測試 $type裡面的字串不等於"withdraw" or "Deposit"錯誤訊息
     */
    public function testErrorTypeString()
    {
        $client = static::createClient();
        $data = array('money' => 1, 'type' => 'test');
        $client->request('POST',
            '/api/bank/1/new',
            $data,
            array(),
            array(),
            ['Content-Type' => 'application/x-www-form-urlencoded']);
        $this->assertEquals(200, $client->getResponse()->getStatusCode());
        $this->assertEquals("type error!", json_decode($client->getResponse()->getContent()));
    }

    /**
     * 測試顯示所有明細
     */
    public function testShowRecordsAction()
    {
        $client = static::createClient();
        $client->request('GET', '/api/bank/show?page=1&count=5');
        $url = parse_url('api/bank/show?page=1&count=5', PHP_URL_QUERY);
        $params = array();
        parse_str($url, $params);
        $this->assertEquals(1, $params['page']);
        $this->assertEquals(5, $params['count']);
        $this->assertTrue($client->getResponse()->isSuccessful());
    }

    /**
     * 測試get $page 錯誤訊息
     */
    public function testErrorGetPage()
    {
        $client = static::createClient();
        $client->request('GET', '/api/bank/show?page=test&count=5');
        $this->assertTrue($client->getResponse()->isSuccessful());
        $this->assertEquals("page is not integer!", json_decode($client->getResponse()->getContent()));
    }

    /**
     * 測試get $count 錯誤訊息
     */
    public function testErrorGetCount()
    {
        $client = static::createClient();
        $client->request('GET', '/api/bank/show?page=1&count=test');
        $this->assertTrue($client->getResponse()->isSuccessful());
        $this->assertEquals("count is not integer!", json_decode($client->getResponse()->getContent()));
    }
}
